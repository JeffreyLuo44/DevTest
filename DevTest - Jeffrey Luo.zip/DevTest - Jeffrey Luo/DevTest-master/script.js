let count = 0;
function countLearnMoreButtonClick() {
    //Increment once every time the 'Learn More' button is clicked
    count++;
    console.log("You clicked a 'Learn More' button " + count + " time(s) in this webpage instance");
    alert("You clicked a 'Learn More' button " + count + " time(s) in this webpage instance"); 
}

